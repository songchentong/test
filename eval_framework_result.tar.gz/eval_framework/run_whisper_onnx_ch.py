"""Entry point for the Whisper ONNX real-case evaluation pipeline."""

import argparse
import csv
import re
import sys
from pathlib import Path
from opencc import OpenCC

# Ensure Whisper ONNX plugins are imported and registered.
import plugins.whisper_onnx_dataset
import plugins.whisper_onnx_inference
import plugins.whisper_onnx_model

from eval_framework import Config, Logger, Runner
from jiwer import cer
from datasets import load_dataset


def normalize_chinese(text):
    """去空格、去标点、只保留汉字"""
    text = text.replace(" ", "")
    text = re.sub(r'[^\u4e00-\u9fffa-zA-Z0-9]', '', text)
    text = text.lower()
    return text


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run Whisper ONNX transcription through the eval framework."
    )
    parser.add_argument(
        "--config",
        "-c",
        default="configs/whisper_onnx_config.yaml",
        help="Path to the JSON or YAML configuration file.",
    )
    parser.add_argument(
        "--output",
        "-o",
        default="whipser_cer_results.csv",
        help="Output CSV file for per-sample CER.",
    )
    args = parser.parse_args(argv)

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"Config file not found: {config_path}", file=sys.stderr)
        return 1

    config = Config(str(config_path))
    Logger(config.log_level)
    runner = Runner(config)
    result = runner.run()

    transcriptions = result.get("inference", [])

    model_name = "whisper"
    quant_precision = "INT8"

    dataset_path = config.get("dataset")
    num_records = 945

    try:
        dataset = load_dataset(
            "arrow",
            data_files={
                "test": [
                    f"{dataset_path}/test/data-00000-of-00002.arrow",
                    f"{dataset_path}/test/data-00001-of-00002.arrow",
                ]
            },
        )
    except Exception as e:
        print(f"Failed to load dataset: {e}", file=sys.stderr)
        return 1

    print(f"测试集总数: {len(dataset['test'])}")

    samples_raw = []
    references_clean = []
    for i, sample in enumerate(dataset["test"]):
        if i >= num_records:
            break
        samples_raw.append(sample)
        references_clean.append(sample["transcription"].replace(" ", ""))

    if not references_clean:
        print("No reference texts found.", file=sys.stderr)
        return 1

    if len(references_clean) != len(transcriptions):
        print(
            f"Error: number of references ({len(references_clean)}) does not match "
            f"number of transcriptions ({len(transcriptions)}).",
            file=sys.stderr,
        )
        return 1

    # 创建繁转简转换器（只创建一次）
    cc = OpenCC('t2s')

    # 批量处理：繁转简 + 去标点空格
    transcriptions_clean = [normalize_chinese(cc.convert(hyp)) for hyp in transcriptions]
    references_clean_norm = [normalize_chinese(ref) for ref in references_clean]

    # ---------- 写入 CSV ----------
    csv_path = args.output
    with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
        fieldnames = [
            "序号",
            "样本ID",
            "模型名称",
            "量化精度",
            "参考文本原始",
            "标注文本（规范化）",
            "模型识别结果",
            "CER",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for idx, (sample, ref_norm, hyp_clean) in enumerate(
            zip(samples_raw, references_clean_norm, transcriptions_clean)
        ):
            sample_cer = cer(ref_norm, hyp_clean)

            if idx < 50:
                print(f"[{idx}] Ref : {ref_norm}")
                print(f"[{idx}] Hyp : {hyp_clean}")
                print(f"[{idx}] CER : {sample_cer:.4f}")
                print("-" * 40)

            writer.writerow({
                "序号": idx + 1,
                "样本ID": sample["id"],
                "模型名称": model_name,
                "量化精度": quant_precision,
                "参考文本原始": sample["raw_transcription"],
                "标注文本（规范化）": ref_norm,
                "模型识别结果": hyp_clean,
                "CER": f"{sample_cer:.6f}",
            })

    # ---------- 总体 CER ----------
    overall_cer = cer(references_clean_norm, transcriptions_clean)
    print(f"Per-sample CER saved to: {csv_path}")
    print(f"Total samples: {len(transcriptions_clean)}")
    print(f"Overall CER: {overall_cer:.4f} ({overall_cer*100:.2f}%)")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())