"""Entry point for the Whisper ONNX real-case evaluation pipeline.

Supports both FLEURS and AISHELL datasets.
"""

import argparse
import csv
import re
import sys
from pathlib import Path
from opencc import OpenCC

# Ensure Whisper ONNX plugins are imported and registered.
import plugins.whisper_onnx_dataset
import plugins.whisper_onnx_inference
import plugins.whisper_onnx_model

from eval_framework import Config, Logger, Runner
from jiwer import cer


def normalize_chinese(text):
    """去空格、去标点，保留汉字、字母、数字，英文转小写"""
    text = text.replace(" ", "")
    text = re.sub(r'[^\u4e00-\u9fffa-zA-Z0-9]', '', text)
    text = text.lower()
    return text


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run Whisper ONNX transcription through the eval framework."
    )
    parser.add_argument(
        "--config",
        "-c",
        default="configs/whisper_onnx_config.yaml",
        help="Path to the YAML configuration file.",
    )
    parser.add_argument(
        "--output",
        "-o",
        default="whisper_aishell_cer_results.csv",
        help="Output CSV file for per-sample CER.",
    )
    args = parser.parse_args(argv)

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"Config file not found: {config_path}", file=sys.stderr)
        return 1

    config = Config(str(config_path))
    Logger(config.log_level)
    runner = Runner(config)
    result = runner.run()

    # 从 result 获取推理结果、参考文本和样本ID
    transcriptions = result.get("transcriptions", [])
    references = result.get("references", [])
    sample_ids = result.get("sample_ids", [])

    # 兼容旧版：若 references 为空，尝试从 result 中找（可能未修改推理插件）
    if not references:
        # 对于 FLEURS，可以尝试使用旧逻辑重新加载数据集，但这里直接报错
        print(
            "No reference texts found in result. "
            "Please update the inference plugin to collect references.",
            file=sys.stderr,
        )
        return 1

    if len(references) != len(transcriptions):
        print(
            f"Error: number of references ({len(references)}) does not match "
            f"number of transcriptions ({len(transcriptions)}).",
            file=sys.stderr,
        )
        return 1

    # 模型信息（可写死或从配置读取）
    model_name = "whisper"
    quant_precision = "FP32" 
    data_text = "aishell"

    # 创建繁转简转换器
    cc = OpenCC('t2s')

    # 批量处理：繁转简 + 规范化
    transcriptions_clean = [
        normalize_chinese(cc.convert(hyp)) for hyp in transcriptions
    ]
    references_clean = [
        normalize_chinese(ref) for ref in references
    ]

    # ---------- 写入 CSV ----------
    csv_path = args.output
    with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
        fieldnames = [
            "序号",
            "样本ID",
            "模型名称",
            "量化精度",
            "数据集",
            "参考文本原始",
            "标注文本（规范化）",
            "模型识别结果",
            "CER",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for idx, (sid, ref_raw, ref_norm, hyp_clean) in enumerate(
            zip(sample_ids, references, references_clean, transcriptions_clean)
        ):
            sample_cer = cer(ref_norm, hyp_clean)

            if idx < 50:
                print(f"[{idx}] ID : {sid}")
                print(f"      Ref : {ref_norm}")
                print(f"      Hyp : {hyp_clean}")
                print(f"      CER : {sample_cer:.4f}")
                print("-" * 40)

            writer.writerow({
                "序号": idx + 1,
                "样本ID": sid,
                "模型名称": model_name,
                "量化精度": quant_precision,
                "数据集": data_text,
                "参考文本原始": ref_raw,          # 原始标注文本（含空格/分词）
                "标注文本（规范化）": ref_norm,
                "模型识别结果": hyp_clean,
                "CER": f"{sample_cer:.6f}",
            })

    # ---------- 总体 CER ----------
    overall_cer = cer(references_clean, transcriptions_clean)
    print(f"Per-sample CER saved to: {csv_path}")
    print(f"Total samples: {len(transcriptions_clean)}")
    print(f"Overall CER: {overall_cer:.4f} ({overall_cer*100:.2f}%)")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())