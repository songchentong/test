#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import tempfile
import datasets
from pathlib import Path

import imageio_ffmpeg
import numpy as np
import onnxruntime as ort
import scipy.io.wavfile as wavfile
from transformers import WhisperProcessor


SAMPLE_RATE = 16000
INT16_MAX = 32768.0
MODEL_ID = "openai/whisper-tiny"
DEFAULT_LANGUAGE = "en"
DEFAULT_TASK = "transcribe"



def make_prompt(processor: WhisperProcessor, language: str, task: str) -> np.ndarray:
    tokenizer = processor.tokenizer
    tokens = [
        "<|startoftranscript|>",
        f"<|{language}|>",
        f"<|{task}|>",
        "<|notimestamps|>",
    ]
    token_ids = tokenizer.convert_tokens_to_ids(tokens)
    if any(token_id is None or token_id == tokenizer.unk_token_id for token_id in token_ids):
        raise ValueError(f"Could not resolve Whisper prompt tokens: {tokens} -> {token_ids}")
    return np.array([token_ids], dtype=np.int64)


def run_decoder_prefill(
    decoder_session: ort.InferenceSession,
    input_ids: np.ndarray,
    encoder_hidden_states: np.ndarray,
) -> dict[str, np.ndarray]:
    output_names = [output.name for output in decoder_session.get_outputs()]
    outputs = decoder_session.run(
        output_names,
        {
            "input_ids": input_ids.astype(np.int64),
            "encoder_hidden_states": encoder_hidden_states.astype(np.float32),
        },
    )
    return dict(zip(output_names, outputs))


def build_past_inputs(
    decoder_with_past_session: ort.InferenceSession,
    kv_cache: dict[str, np.ndarray],
) -> dict[str, np.ndarray]:
    feeds = {}
    missing = []
    for model_input in decoder_with_past_session.get_inputs():
        if model_input.name == "input_ids":
            continue
        if model_input.name not in kv_cache:
            missing.append(model_input.name)
            continue
        feeds[model_input.name] = kv_cache[model_input.name]
    if missing:
        raise RuntimeError("Missing KV cache tensors: " + ", ".join(missing))
    return feeds


def run_decoder_with_past(
    decoder_with_past_session: ort.InferenceSession,
    input_id: int,
    kv_cache: dict[str, np.ndarray],
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    output_names = [output.name for output in decoder_with_past_session.get_outputs()]
    feeds = build_past_inputs(decoder_with_past_session, kv_cache)
    feeds["input_ids"] = np.array([[input_id]], dtype=np.int64)
    outputs = decoder_with_past_session.run(output_names, feeds)
    output_map = dict(zip(output_names, outputs))
    next_cache = dict(kv_cache)
    for name, value in output_map.items():
        if name.startswith("present.") and ".decoder." in name:
            next_cache[name.replace("present.", "past_key_values.", 1)] = value
    return output_map["logits"], next_cache


def greedy_decode(
    prefill_session: ort.InferenceSession,
    decoder_with_past_session: ort.InferenceSession,
    processor: WhisperProcessor,
    encoder_hidden_states: np.ndarray,
    prompt_ids: np.ndarray,
    max_new_tokens: int,
) -> list[int]:
    generated = prompt_ids[0].astype(np.int64).tolist()
    eos_id = int(processor.tokenizer.eos_token_id)
    prefill_outputs = run_decoder_prefill(prefill_session, prompt_ids, encoder_hidden_states)
    logits = prefill_outputs["logits"]
    kv_cache = {
        name.replace("present.", "past_key_values.", 1): value
        for name, value in prefill_outputs.items()
        if name.startswith("present.")
    }
    for step in range(max_new_tokens):
        next_id = int(np.argmax(logits[0, -1]))
        generated.append(next_id)
        if next_id == eos_id or step == max_new_tokens - 1:
            break
        logits, kv_cache = run_decoder_with_past(decoder_with_past_session, next_id, kv_cache)
    return generated


def parse_args() -> argparse.Namespace:
    here = Path(__file__).resolve().parent
    root = here.parent
    default_audio = root / "0.wav" if (root / "0.wav").exists() else here / "0.wav"
    parser = argparse.ArgumentParser(description="Run Whisper ONNX transcription.")
    parser.add_argument("--audio", type=Path, default=default_audio)
    parser.add_argument("--encoder", type=Path, default=here / "encoder_model.onnx")
    parser.add_argument("--decoder-prefill", type=Path, default=root / "decoder_prefill" / "decoder_prefill.onnx")
    parser.add_argument("--decoder-with-past", type=Path, default=root / "decoder_with_past_model_q4.onnx")
    parser.add_argument("--language", default=DEFAULT_LANGUAGE)
    parser.add_argument("--task", choices=["transcribe", "translate"], default=DEFAULT_TASK)
    parser.add_argument("--model-id", default=MODEL_ID)
    parser.add_argument("--max-new-tokens", type=int, default=64)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    processor = WhisperProcessor.from_pretrained(args.model_id)
    encoder_session = ort.InferenceSession(str(args.encoder))
    prefill_session = ort.InferenceSession(str(args.decoder_prefill))
    decoder_with_past_session = ort.InferenceSession(str(args.decoder_with_past))
    ds = datasets.load_from_disk("fluer")
    rec = ds["test"][0]["audio"]
    audio = rec.get_all_samples().data.numpy()
    input_features = processor.feature_extractor(
        audio, sampling_rate=SAMPLE_RATE, return_tensors="np"
    )["input_features"].astype(np.float32)
    encoder_hidden_states = encoder_session.run(
        ["last_hidden_state"], {"input_features": input_features}
    )[0]
    prompt_ids = make_prompt(processor, args.language, args.task)
    generated = greedy_decode(
        prefill_session,
        decoder_with_past_session,
        processor,
        encoder_hidden_states,
        prompt_ids,
        args.max_new_tokens,
    )
    print(processor.tokenizer.decode(generated, skip_special_tokens=True).strip())


if __name__ == "__main__":
    main()
