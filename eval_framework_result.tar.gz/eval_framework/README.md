# Model Inference Framework

A pure model evaluation framework. It does not actually run models; instead it
provides a register mechanism that lets users fully customize actions for each
stage of an evaluation pipeline.

## Pipeline

A typical evaluation pipeline is:

```
Load Dataset -> Data Preprocess -> Load Model -> Inference -> Collect data -> Process Result -> Measurements
```

Each stage is a module. Users write their own implementations, register them,
and describe the pipeline in a JSON or YAML configuration file.

## Quick Start

```bash
python main.py --config configs/example_config.yaml
```

## Writing a Plugin

Plugins can be functions or classes. Register them with the global registry:

```python
from eval_framework import register

@register("measurer", "my_metric")
def my_metric(collector, *args, **kwargs):
    predictions = collector.get("predictions", [])
    return {"count": len(predictions)}
```

Functions and classes can declare ``*args`` and ``**kwargs`` to receive the
positional and keyword arguments configured for that pipeline step.

## Passing Arguments per Pipeline Step

Each pipeline step declares its own ``action`` and can optionally provide
``args`` (a list of positional arguments) and ``kwargs`` (a dictionary of
keyword arguments). The top-level ``model`` and ``dataset`` keys are no longer
injected automatically; if a step needs them, list them in that step's
``args`` or ``kwargs``.

```yaml
pipelines:
  - load_dataset:
      action: dummy_json
      args:
        - "data/dataset.json"
  - load_model:
      action: dummy
      args:
        - "models/dummy-model"
  - inference:
      action: dummy
  - measurement:
      action: dummy_accuracy
```

## Sharing Runtime Data

Stages that need data produced by earlier stages (for example, inference needs
the loaded model and preprocessed samples) can read from the shared
:class:`Collector`. The runner automatically stores each stage's return value
under the stage name, and plugins can also write arbitrary data to the
collector explicitly.

## Modules

- **Registry**: central plugin registry (functions, classes, decorators).
- **Logger**: global logging helper.
- **Collector**: stores intermediate data produced during evaluation.
- **Dataset Processor**: loads and preprocesses datasets.
- **Model Loader**: loads a model.
- **Inference Engine**: runs inference on samples.
- **Measurer**: computes final metrics.

## Tests

```bash
python -m pytest tests/ -v
```
