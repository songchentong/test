"""Entry point for the Whisper ONNX real-case evaluation pipeline – English WER."""

import argparse
import csv
import sys
from pathlib import Path
import re
import plugins.whisper_onnx_dataset
import plugins.whisper_onnx_inference
import plugins.whisper_onnx_model

from eval_framework import Config, Logger, Runner
from jiwer import wer
from datasets import load_dataset
def normalize_text(text):
    """统一文本格式：转小写、去标点（保留空格）"""
    text = text.lower()  # 转小写
    text = re.sub(r'[^\w\s]', '', text)  # 去掉标点符号（保留字母、数字、空格）
    text = re.sub(r'\s+', ' ', text)  # 合并多余空格
    text = text.strip()
    return text

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run Whisper ONNX transcription and compute English WER."
    )
    parser.add_argument(
        "--config",
        "-c",
        default="configs/whisper_onnx_config.yaml",
        help="Path to the YAML configuration file.",
    )
    parser.add_argument(
        "--output",
        "-o",
        default="whisper_wer_results.csv",
        help="Output CSV file for per-sample WER.",
    )
    args = parser.parse_args(argv)

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"Config file not found: {config_path}", file=sys.stderr)
        return 1

    config = Config(str(config_path))
    Logger(config.log_level)
    runner = Runner(config)
    result = runner.run()

    transcriptions = result.get("inference", [])

    model_name = "whisper"
    quant_precision = "FP32"
    data_text = "fleurs_en_us"

    dataset_path = config.get("dataset")  # "/home/lqsw/workspace/google_fleurs/en_us"
    num_records = 647

    try:
        dataset = load_dataset(
            "arrow",
            data_files={
                "test": [f"{dataset_path}/test/data-00000-of-00001.arrow"]
            },
        )
        print(f"测试集总数: {len(dataset['test'])}")

    except Exception as e:
        print(f"Failed to load dataset: {e}", file=sys.stderr)
        return 1
    # 收集参考文本（英文已按单词空格分隔，直接使用）
    samples_raw = []
    references = []
    total_available = len(dataset["test"])
    max_samples = num_records if num_records is not None else total_available

    for i, sample in enumerate(dataset["test"]):
        if i >= max_samples:
            break
        samples_raw.append(sample)
        # 英文 transcription 通常为 "the cat sat on the mat" 形式
        references.append(sample["transcription"].strip())

    if not references:
        print("No reference texts found.", file=sys.stderr)
        return 1

    if len(references) != len(transcriptions):
        print(
            f"Error: number of references ({len(references)}) does not match "
            f"number of transcriptions ({len(transcriptions)}).",
            file=sys.stderr,
        )
        return 1

    # ---------- 写入 CSV ----------
    csv_path = args.output
    with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
        fieldnames = [
            "序号",
            "样本ID",
            "模型名称",
            "量化精度",
            "测试数据集",
            "参考文本原始",
            "标注文本（已分词）",
            "模型识别结果",
            "WER",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for idx, (sample, ref, hyp) in enumerate(
            zip(samples_raw, references, transcriptions)
        ):
            
            # ref_normalized = normalize_text(ref)
            print(f"标注语句：{ref}")
            hyp_normalized = normalize_text(hyp)
            print(f"模型输出：{hyp_normalized}")
            sample_wer = wer(ref, hyp_normalized)

            writer.writerow({
                "序号": idx + 1,
                "样本ID": sample["id"],
                "模型名称": model_name,
                "量化精度": quant_precision,
                "测试数据集": data_text,
                "参考文本原始": sample.get("raw_transcription", "N/A"),
                "标注文本（已分词）": ref,
                "模型识别结果": hyp_normalized,
                "WER": f"{sample_wer:.6f}",
            })

    # ---------- 总体 WER ----------
    transcriptions_normalized = [normalize_text(hyp) for hyp in transcriptions]
    overall_wer = wer(references, transcriptions_normalized)
    print(f"Per-sample WER saved to: {csv_path}")
    print(f"Evaluated samples: {len(transcriptions)}")
    print(f"Overall WER: {overall_wer:.4f} ({overall_wer*100:.2f}%)")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())


