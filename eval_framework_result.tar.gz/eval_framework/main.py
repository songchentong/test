"""Entry point for running an evaluation pipeline."""

import argparse
import sys
from pathlib import Path

# Ensure plugins are imported and registered.
import plugins.example_collector
import plugins.example_dataset_processor
import plugins.example_inference_engine
import plugins.example_measurer
import plugins.example_model_loader
import plugins.example_processor

from eval_framework import Config, Logger, Runner


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run an evaluation pipeline.")
    parser.add_argument(
        "--config",
        "-c",
        required=True,
        help="Path to the JSON or YAML configuration file.",
    )
    args = parser.parse_args(argv)

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"Config file not found: {config_path}", file=sys.stderr)
        return 1

    config = Config(str(config_path))
    Logger(config.log_level)
    runner = Runner(config)
    result = runner.run()
    print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
