"""Unit tests for the registry module."""

import pytest

from eval_framework.registry import Registry


def test_register_and_get_function():
    registry = Registry()

    @registry.register("dataset_processor", "my_func")
    def my_func():
        return 42

    assert registry.has("dataset_processor", "my_func")
    assert registry.get("dataset_processor", "my_func")() == 42


def test_register_and_get_class():
    registry = Registry()

    @registry.register("model_loader", "my_class")
    class MyClass:
        pass

    assert registry.has("model_loader", "my_class")
    assert isinstance(registry.get("model_loader", "my_class")(), MyClass)


def test_register_conflict():
    registry = Registry()

    @registry.register("module", "name")
    def first():
        pass

    with pytest.raises(ValueError):

        @registry.register("module", "name")
        def second():
            pass


def test_list_plugins():
    registry = Registry()

    @registry.register("a", "x")
    def x():
        pass

    @registry.register("a", "y")
    def y():
        pass

    assert registry.list_plugins("a") == {"a": ["x", "y"]}


def test_check_conflicts():
    registry = Registry()

    @registry.register("module_a", "shared_name")
    def shared_name():
        pass

    @registry.register("module_b", "shared_name")
    class shared_name:
        pass

    conflicts = registry.check_conflicts()
    assert len(conflicts) == 1
    assert "shared_name" in conflicts[0]
