"""Smoke tests for the evaluation runner."""

import json
from pathlib import Path

# Import plugins so they register.
import plugins.example_collector
import plugins.example_dataset_processor
import plugins.example_inference_engine
import plugins.example_measurer
import plugins.example_model_loader
import plugins.example_processor

from eval_framework import Config, Runner


def test_dummy_pipeline(tmp_path: Path):
    dataset_path = tmp_path / "data.json"
    dataset_path.write_text(json.dumps([{"x": 1}, {"x": 2}]))

    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        f"""
model: "models/dummy-model"
dataset: "{dataset_path.as_posix()}"
dataset_proc: "dummy_list"
log_level: "DEBUG"
pipelines:
  - load_dataset:
      action: dummy_json
      args:
        - "{dataset_path.as_posix()}"
  - load_model:
      action: dummy
      args:
        - "models/dummy-model"
  - inference:
      action: dummy
  - measurement:
      action: dummy_accuracy
"""
    )

    config = Config(str(config_path))
    runner = Runner(config)
    result = runner.run()

    metrics = result["measurement"]
    assert metrics["accuracy"] == 1.0
    assert metrics["total"] == 2
    assert metrics["correct"] == 2
