"""Example plugins for the evaluation framework."""
