"""Whisper ONNX inference engine plugin.

Runs encoder + greedy decoder transcription on audio samples loaded by the
dataset processor.
"""

from typing import Any, List

import numpy as np

from eval_framework import register

SAMPLE_RATE = 16000


@register("inference_engine", "whisper_onnx")
def whisper_onnx_inference(
    collector: Any,
    *args: Any,
    language: str = "en",
    task: str = "transcribe",
    max_new_tokens: int = 64,
    **kwargs: Any,
) -> List[str]:
    """Transcribe audio samples using the loaded Whisper ONNX model.

    Args:
        collector: Shared collector. Must contain ``load_model`` (processor and
            ONNX sessions) and ``load_dataset`` (audio records).
        language: Whisper language token, e.g. ``en``.
        task: Whisper task, either ``transcribe`` or ``translate``.
        max_new_tokens: Maximum number of tokens to generate.

    Returns:
        A list of transcription strings, one per input sample.
    """
    # Import helper functions from the reference script lazily so that the
    # plugin module can be imported even when ONNX dependencies are absent.
    from transcribe_onnx_audio import greedy_decode, make_prompt

    model = collector.get("load_model")
    samples = collector.get("load_dataset", [])

    processor = model["processor"]
    encoder_session = model["encoder_session"]
    prefill_session = model["prefill_session"]
    decoder_with_past_session = model["decoder_with_past_session"]

    transcriptions: List[str] = []
    references: List[str] = []
    sample_ids: List[str] = []

    for sample in samples:
        audio = sample["audio"]
        input_features = processor.feature_extractor(
            audio,
            sampling_rate=SAMPLE_RATE,
            return_tensors="np",
        )["input_features"].astype(np.float32)

        encoder_hidden_states = encoder_session.run(
            ["last_hidden_state"],
            {"input_features": input_features},
        )[0]

        prompt_ids = make_prompt(processor, language, task)
        generated = greedy_decode(
            prefill_session,
            decoder_with_past_session,
            processor,
            encoder_hidden_states,
            prompt_ids,
            max_new_tokens,
        )
        text = processor.tokenizer.decode(
            generated,
            skip_special_tokens=True,
        ).strip()
        transcriptions.append(text)
        references.append(sample.get("reference", ""))
        sample_ids.append(sample.get("id", str(sample.get("index", ""))))

    collector.set("transcriptions", transcriptions)
    collector.set("references", references)
    collector.set("sample_ids", sample_ids)
    return transcriptions
