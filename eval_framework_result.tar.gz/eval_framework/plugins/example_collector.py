"""Example collector action plugins."""

from typing import Any

from eval_framework import register


@register("collector", "log_keys")
def log_collector_keys(
    collector: Any,
    logger: Any,
    *args: Any,
    **kwargs: Any,
) -> None:
    """Log all keys currently stored in the collector."""
    logger.info(f"Collector keys: {collector.keys()}")
