"""Example measurer plugins."""

from typing import Any, Dict

from eval_framework import register
from eval_framework.modules import Measurer


@register("measurer", "dummy_accuracy")
def dummy_accuracy(
    collector: Any,
    *args: Any,
    **kwargs: Any,
) -> Dict[str, Any]:
    """Compute a dummy accuracy metric from collected predictions."""
    predictions = collector.get("predictions", [])
    total = len(predictions)
    correct = sum(1 for p in predictions if p.get("prediction") == "dummy-output")
    accuracy = correct / total if total else 0.0
    return {"accuracy": accuracy, "total": total, "correct": correct}


@register("measurer", "count_samples")
class CountSamplesMeasurer(Measurer):
    """Class-based measurer that counts collected samples and predictions."""

    def run(self, *args: Any, **kwargs: Any) -> Dict[str, Any]:
        collector_data = self.collector.as_dict()
        return {
            "num_samples": len(collector_data.get("samples", [])),
            "num_predictions": len(collector_data.get("predictions", [])),
        }
