"""Whisper ONNX dataset processor plugin.

Loads audio samples from a HuggingFace ``datasets`` dataset stored on disk,
such as the ``fluer`` dataset used by ``transcribe_onnx_audio.py``.
"""

from typing import Any, Dict, List
from pathlib import Path
from eval_framework import register
import soundfile as sf
import numpy as np  
@register("dataset_processor", "whisper_fleur")
def whisper_fleur_dataset(
    dataset_path: str,
    *args: Any,
    split: str = "test",
    num_records: int | None = None,
    audio_column: str = "audio",
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """Load audio records from a HuggingFace dataset on disk.

    Args:
        dataset_path: Path passed to ``datasets.load_from_disk``.
        split: Dataset split to use, e.g. ``test``.
        num_records: Maximum number of records to load. ``None`` means all.
        audio_column: Name of the audio column in the dataset.

    Returns:
        A list of records. Each record contains the decoded audio numpy array
        and the original sample index.
    """
    import datasets

    ds = datasets.load_from_disk(dataset_path)
    split_ds = ds[split]
    total = min(num_records, len(split_ds)) if num_records is not None else len(split_ds)

    records: List[Dict[str, Any]] = []
    for i in range(total):
        rec = split_ds[i][audio_column]
        audio = rec.get_all_samples().data.numpy()
        records.append({"audio": audio, "index": i})
    return records



@register("dataset_processor", "whisper_aishell")
def whisper_aishell_dataset(
    dataset_path: str,
    *args: Any,
    split: str = "test",
    num_records: int | None = None,
    audio_column: str = "audio",
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """Load audio records from AISHELL dataset.

    Automatically finds wav files and transcription file in the given directory.
    Supports two directory structures:

    1. Flat::
        dataset_path/
        ├── *.wav
        └── trans.txt (or *.txt)

    2. Nested::
        dataset_path/
        ├── wav/
        │   └── *.wav
        └── trans.txt

    trans.txt format (space-separated)::

        BAC009S0002W0122 而 对 楼市 成交 抑制 作用 最 大 的 限 购

    Args:
        dataset_path: Path to the AISHELL directory.
        num_records: Maximum number of records to load. ``None`` means all.

    Returns:
        A list of records with audio, index, reference, and id.
    """
    data_dir = Path(dataset_path)

    # ---- 查找转录文件 ----
    trans_file = None
    # 先找 trans.txt 或 *.txt（排除非标注的 txt）
    for candidate in data_dir.rglob("*.txt"):
        # 读取第一行判断是否是标注格式（ID + 空格 + 文本）
        try:
            with open(candidate, "r", encoding="utf-8") as f:
                first_line = f.readline().strip()
                parts = first_line.split(maxsplit=1)
                if len(parts) == 2 and len(parts[1]) > 0:
                    trans_file = candidate
                    break
        except Exception:
            continue

    if trans_file is None:
        raise FileNotFoundError(f"No valid transcription file found in {dataset_path}")

    # ---- 读取标注 ----
    transcripts: Dict[str, str] = {}
    with open(trans_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(maxsplit=1)
            if len(parts) == 2:
                transcripts[parts[0]] = parts[1]

    # ---- 查找 wav 文件 ----
    # 优先找 wav/ 子目录，没有则找根目录
    wav_dir = data_dir / "wav"
    if not wav_dir.exists():
        wav_dir = data_dir

    wav_files = sorted(wav_dir.rglob("*.wav"))

    # ---- 加载音频 ----
    total = min(num_records, len(wav_files)) if num_records is not None else len(wav_files)

    records: List[Dict[str, Any]] = []
    count = 0

    for wav_path in wav_files:
        if count >= total:
            break

        utt_id = wav_path.stem
        if utt_id not in transcripts:
            continue

        audio, sr = sf.read(str(wav_path))
        if sr != 16000:
            continue
        if audio.ndim > 1:
            audio = audio[:, 0]
        audio = audio.astype(np.float32)

        records.append({
            "audio": audio,
            "index": count,
            "reference": transcripts[utt_id],
            "id": utt_id,
        })
        count += 1

    return records