"""Example model loader plugins."""

from typing import Any, Dict

from eval_framework import register
from eval_framework.modules import ModelLoader


@register("model_loader", "dummy")
def dummy_model_loader(model_path: str, *args: Any, **kwargs: Any) -> Dict[str, Any]:
    """Return a dummy model object."""
    return {"path": model_path, "type": "dummy"}


@register("model_loader", "echo")
class EchoModelLoader(ModelLoader):
    """Class-based model loader that returns the model path as the model."""

    def run(self, model_path: str, *args: Any, **kwargs: Any) -> Any:
        self.logger.info(f"Loading model from {model_path}")
        return {"model_path": model_path}
