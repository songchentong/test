"""Example inference engine plugins."""

from typing import Any, Dict, Iterable, List

from eval_framework import register
from eval_framework.modules import InferenceEngine


@register("inference_engine", "dummy")
def dummy_inference_engine(
    collector: Any,
    *args: Any,
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """Return dummy predictions for every sample.

    Reads the loaded model and samples from the collector.
    """
    model = collector.get("load_model")
    samples = collector.get("load_dataset", [])
    results = []
    for sample in samples:
        results.append({"input": sample, "prediction": "dummy-output", "model": model})
    collector.set("predictions", results)
    return results


@register("inference_engine", "echo")
class EchoInferenceEngine(InferenceEngine):
    """Class-based inference engine that echoes inputs as predictions."""

    def run(self, *args: Any, **kwargs: Any) -> Iterable[Any]:
        samples = self.collector.get("load_dataset", [])
        self.logger.info(f"Running inference on {len(samples)} samples")
        results = []
        for sample in samples:
            results.append({"input": sample, "prediction": sample})
        self.collector.set("predictions", results)
        return results
