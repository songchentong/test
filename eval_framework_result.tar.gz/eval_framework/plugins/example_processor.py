"""Example result processor plugins."""

from typing import Any, Iterable, List

from eval_framework import register


@register("processor", "identity")
def identity_processor(
    collector: Any,
    *args: Any,
    **kwargs: Any,
) -> List[Any]:
    """Return predictions unchanged."""
    predictions = collector.get("predictions", [])
    return list(predictions)


@register("processor", "extract_prediction")
def extract_prediction(
    collector: Any,
    *args: Any,
    **kwargs: Any,
) -> List[Any]:
    """Extract the 'prediction' field from each prediction dict."""
    predictions = collector.get("predictions", [])
    return [p.get("prediction") for p in predictions]
