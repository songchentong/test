"""Whisper ONNX model loader plugin.

Loads the Whisper processor and ONNX runtime sessions needed for transcription.
"""

from typing import Any, Dict

from eval_framework import register


@register("model_loader", "whisper_onnx")
def whisper_onnx_model(
    model_id: str,
    encoder_path: str,
    decoder_prefill_path: str,
    decoder_with_past_path: str,
    *args: Any,
    **kwargs: Any,
) -> Dict[str, Any]:
    """Load Whisper ONNX model artifacts.

    Args:
        model_id: HuggingFace model id used to load the ``WhisperProcessor``.
        encoder_path: Path to the encoder ONNX model.
        decoder_prefill_path: Path to the decoder prefill ONNX model.
        decoder_with_past_path: Path to the decoder-with-past ONNX model.

    Returns:
        A dictionary containing the processor and ONNX runtime sessions.
    """
    import onnxruntime as ort
    from transformers import WhisperProcessor

    processor = WhisperProcessor.from_pretrained(model_id)
    encoder_session = ort.InferenceSession(str(encoder_path))
    prefill_session = ort.InferenceSession(str(decoder_prefill_path))
    decoder_with_past_session = ort.InferenceSession(str(decoder_with_past_path))

    return {
        "processor": processor,
        "encoder_session": encoder_session,
        "prefill_session": prefill_session,
        "decoder_with_past_session": decoder_with_past_session,
    }
