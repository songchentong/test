"""Example dataset processor plugins."""

from typing import Any, Dict, Iterable, List

from eval_framework import register
from eval_framework.modules import DatasetProcessor


@register("dataset_processor", "dummy_json")
def dummy_json_dataset_processor(
    dataset_path: str, *args: Any, **kwargs: Any
) -> Iterable[Dict[str, Any]]:
    """Load a JSON dataset and return its contents as samples."""
    import json

    with open(dataset_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    return [data]


@register("dataset_processor", "dummy_list")
def dummy_list_dataset_processor(*args: Any, **kwargs: Any) -> List[str]:
    """Return a few dummy samples for quick smoke tests."""
    return ["sample-a", "sample-b", "sample-c"]


@register("dataset_processor", "identity")
class IdentityDatasetProcessor(DatasetProcessor):
    """A class-based dataset processor that returns the dataset path as is."""

    def run(self, dataset_path: str, *args: Any, **kwargs: Any) -> Iterable[Any]:
        self.logger.info(f"Loading dataset from {dataset_path}")
        return [{"source": dataset_path}]
