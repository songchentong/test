"""Model Inference Framework.

A pure model evaluation framework that provides a register mechanism for
customizing actions within an evaluation pipeline.
"""

from .registry import Registry, register
from .logger import Logger
from .collector import Collector
from .config import Config
from .runner import Runner

__all__ = [
    "Registry",
    "register",
    "Logger",
    "Collector",
    "Config",
    "Runner",
]
