"""Global logger for the framework."""

from __future__ import annotations

import logging
import sys
from typing import Optional


class Logger:
    """A thin wrapper around the standard library logging module.

    The logger is configured once from the framework configuration and is
    accessible globally through a singleton instance.
    """

    _instance: Optional["Logger"] = None

    def __new__(cls, level: str = "INFO") -> "Logger":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, level: str = "INFO") -> None:
        if self._initialized:
            return
        self._logger = logging.getLogger("eval_framework")
        self._logger.setLevel(self._normalize_level(level))
        self._setup_handlers()
        self._initialized = True

    def _normalize_level(self, level: str) -> int:
        try:
            return int(level)
        except ValueError:
            return getattr(logging, level.upper(), logging.INFO)

    def _setup_handlers(self) -> None:
        if self._logger.handlers:
            return
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        handler.setFormatter(formatter)
        self._logger.addHandler(handler)

    def set_level(self, level: str) -> None:
        """Change the current log level."""
        self._logger.setLevel(self._normalize_level(level))

    def debug(self, message: str) -> None:
        self._logger.debug(message)

    def info(self, message: str) -> None:
        self._logger.info(message)

    def warning(self, message: str) -> None:
        self._logger.warning(message)

    def error(self, message: str) -> None:
        self._logger.error(message)

    def critical(self, message: str) -> None:
        self._logger.critical(message)
