"""Central registry for user plugins.

The registry is the core concept of the framework. Users register custom
functions or classes under a module namespace, then invoke them by name from
configuration files.
"""

from __future__ import annotations

import functools
import inspect
from typing import Any, Callable, Dict, List, Optional, Type, TypeVar, Union

T = TypeVar("T", bound=Union[Callable[..., Any], Type[Any]])


class Registry:
    """A namespaced registry for functions and classes.

    A single :class:`Registry` instance stores all plugins. Plugins are
    registered under a ``module`` (namespace) and a unique ``name``. Both
    functions and classes can be registered.
    """

    def __init__(self) -> None:
        # module -> name -> plugin
        self._registry: Dict[str, Dict[str, Union[Callable[..., Any], Type[Any]]]] = {}

    def register(
        self,
        module: str,
        name: Optional[str] = None,
        plugin: Optional[T] = None,
    ) -> Union[T, Callable[[T], T]]:
        """Register a plugin under ``module`` with ``name``.

        This method can be used as a decorator or as a regular function call.

        Args:
            module: The namespace this plugin belongs to (e.g. ``dataset_proc``).
            name: Optional explicit name. If omitted, the decorated object's
                ``__name__`` is used.
            plugin: The function/class to register when called as a function.

        Returns:
            The registered plugin or a decorator wrapper.

        Raises:
            ValueError: If a plugin with the same module/name already exists.
        """

        def _do_register(plugin_name: str, plugin_obj: T) -> T:
            module_registry = self._registry.setdefault(module, {})
            if plugin_name in module_registry:
                raise ValueError(
                    f"Plugin '{plugin_name}' already registered in module '{module}'."
                )
            module_registry[plugin_name] = plugin_obj
            return plugin_obj

        if plugin is not None:
            # Called as register(module, name, plugin)
            actual_name = name or getattr(plugin, "__name__", None)
            if actual_name is None:
                raise ValueError("Cannot infer plugin name; please provide 'name'.")
            return _do_register(actual_name, plugin)

        # Used as decorator
        def decorator(plugin_obj: T) -> T:
            actual_name = name or getattr(plugin_obj, "__name__", None)
            if actual_name is None:
                raise ValueError("Cannot infer plugin name; please provide 'name'.")
            _do_register(actual_name, plugin_obj)
            return plugin_obj

        return decorator

    def get(self, module: str, name: str) -> Union[Callable[..., Any], Type[Any]]:
        """Retrieve a registered plugin by module and name.

        Raises:
            KeyError: If the module or plugin is unknown.
        """
        if module not in self._registry:
            raise KeyError(f"Module '{module}' does not exist in the registry.")
        if name not in self._registry[module]:
            raise KeyError(
                f"Plugin '{name}' is not registered in module '{module}'. "
                f"Available: {list(self._registry[module].keys())}"
            )
        return self._registry[module][name]

    def list_modules(self) -> List[str]:
        """Return all registered module names."""
        return list(self._registry.keys())

    def list_plugins(self, module: Optional[str] = None) -> Dict[str, List[str]]:
        """Return registered plugin names.

        If ``module`` is provided, returns only plugins in that module.
        """
        if module is not None:
            if module not in self._registry:
                return {module: []}
            return {module: list(self._registry[module].keys())}
        return {mod: list(plugins.keys()) for mod, plugins in self._registry.items()}

    def has(self, module: str, name: str) -> bool:
        """Return True if ``module/name`` is registered."""
        return module in self._registry and name in self._registry[module]

    def check_conflicts(self) -> List[str]:
        """Inspect registered plugins for potential conflicts.

        Reports plugin names that appear in more than one module, as that may
        indicate an unintended collision when resolving by a short name.
        """
        conflicts: List[str] = []
        name_to_modules: Dict[str, List[str]] = {}
        for module, plugins in self._registry.items():
            for name in plugins:
                name_to_modules.setdefault(name, []).append(module)
        for name, modules in name_to_modules.items():
            if len(modules) > 1:
                conflicts.append(
                    f"Plugin name '{name}' is registered in multiple modules: {modules}."
                )
        return conflicts

    def unregister(self, module: str, name: str) -> None:
        """Remove a plugin from the registry."""
        if module in self._registry and name in self._registry[module]:
            del self._registry[module][name]


# Global default registry.
GLOBAL_REGISTRY = Registry()


def register(
    module: str,
    name: Optional[str] = None,
    plugin: Optional[T] = None,
) -> Union[T, Callable[[T], T]]:
    """Shortcut for registering into the global registry."""
    return GLOBAL_REGISTRY.register(module, name, plugin)
