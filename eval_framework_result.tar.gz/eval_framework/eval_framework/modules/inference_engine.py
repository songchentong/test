"""Inference engine module."""

from __future__ import annotations

from abc import abstractmethod
from typing import Any, Iterable

from .base import Module


class InferenceEngine(Module):
    """Runs inference on preprocessed samples using a loaded model."""

    @abstractmethod
    def run(
        self,
        model: Any,
        samples: Iterable[Any],
        **kwargs: Any,
    ) -> Iterable[Any]:
        """Run inference.

        Args:
            model: The model object loaded by a :class:`ModelLoader`.
            samples: Iterable of preprocessed samples.
            **kwargs: Additional configuration options.

        Returns:
            An iterable of raw predictions/outputs.
        """
        raise NotImplementedError
