"""Model loader module."""

from __future__ import annotations

from abc import abstractmethod
from typing import Any, Dict

from .base import Module


class ModelLoader(Module):
    """Loads a model from a path or identifier.

    The loaded object is stored in the collector so later stages can access it.
    """

    @abstractmethod
    def run(self, model_path: str, **kwargs: Any) -> Any:
        """Load the model.

        Args:
            model_path: Path or identifier for the model.
            **kwargs: Additional configuration options.

        Returns:
            The loaded model object.
        """
        raise NotImplementedError
