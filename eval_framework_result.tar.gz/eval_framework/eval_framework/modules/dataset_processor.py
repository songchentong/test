"""Dataset processor module."""

from __future__ import annotations

from abc import abstractmethod
from typing import Any, Dict, Iterable

from .base import Module


class DatasetProcessor(Module):
    """Loads and preprocesses a dataset.

    Implementations receive ``dataset_path`` and any other configuration
    values, and should yield/return preprocessed samples.
    """

    @abstractmethod
    def run(self, dataset_path: str, **kwargs: Any) -> Iterable[Any]:
        """Load and preprocess the dataset.

        Args:
            dataset_path: Path to the dataset resource.
            **kwargs: Additional configuration options.

        Returns:
            An iterable of preprocessed samples.
        """
        raise NotImplementedError
