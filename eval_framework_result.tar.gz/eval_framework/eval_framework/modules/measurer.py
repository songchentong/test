"""Measurement module."""

from __future__ import annotations

from abc import abstractmethod
from typing import Any, Dict

from .base import Module


class Measurer(Module):
    """Computes final metrics from collected results."""

    @abstractmethod
    def run(self, collector_data: Dict[str, Any], **kwargs: Any) -> Dict[str, Any]:
        """Compute metrics.

        Args:
            collector_data: A dictionary containing all collected data.
            **kwargs: Additional configuration options.

        Returns:
            A dictionary of metric name -> metric value.
        """
        raise NotImplementedError
