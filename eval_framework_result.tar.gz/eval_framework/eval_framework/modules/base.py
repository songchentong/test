"""Base class for all evaluation modules."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict

from ..collector import Collector
from ..logger import Logger


class Module(ABC):
    """Abstract base class for pluggable evaluation modules.

    Every module receives the global logger and collector instances when
    instantiated, and accepts a configuration dictionary for stage-specific
    parameters.
    """

    def __init__(
        self,
        config: Dict[str, Any],
        logger: Logger,
        collector: Collector,
    ) -> None:
        self.config = config
        self.logger = logger
        self.collector = collector

    @abstractmethod
    def run(self, *args: Any, **kwargs: Any) -> Any:
        """Execute the module."""
        raise NotImplementedError
