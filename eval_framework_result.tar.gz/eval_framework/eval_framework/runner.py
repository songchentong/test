"""Pipeline runner that executes evaluation steps in order."""

from __future__ import annotations

import inspect
from typing import Any, Dict, List, Optional

from .collector import Collector
from .config import Config
from .logger import Logger
from .registry import GLOBAL_REGISTRY, Registry


class Runner:
    """Execute an evaluation pipeline described by a configuration file.

    The runner loads plugins from the registry and invokes them in the order
    specified by ``pipelines``. It maintains a shared :class:`Collector` so
    stages can communicate data.

    Each pipeline step is invoked with its own positional (``args``) and
    keyword (``kwargs``) arguments as declared in the configuration file. The
    top-level ``model`` and ``dataset`` keys are no longer injected
    automatically; if a stage needs them, they must be listed in that step's
    ``args`` or ``kwargs``.
    """

    # Mapping from pipeline stage name to the registry module used to resolve it.
    DEFAULT_STAGE_MODULES = {
        "load_dataset": "dataset_processor",
        "preprocess": "dataset_processor",
        "load_model": "model_loader",
        "inference": "inference_engine",
        "collect": "collector",
        "process_result": "processor",
        "measurement": "measurer",
    }

    def __init__(
        self,
        config: Config,
        registry: Optional[Registry] = None,
        logger: Optional[Logger] = None,
        collector: Optional[Collector] = None,
    ) -> None:
        self.config = config
        self.registry = registry or GLOBAL_REGISTRY
        self.logger = logger or Logger(config.log_level)
        self.collector = collector or Collector()
        self.results: List[Any] = []

    def run(self) -> Dict[str, Any]:
        """Run all pipeline stages and return the final collector data."""
        self.logger.info("Starting evaluation pipeline.")

        for step in self.config.pipeline_steps():
            stage = step["stage"]
            action_name = step["action"]
            args = step["args"]
            kwargs = step["kwargs"]

            self.logger.info(
                f"Executing stage '{stage}' with action '{action_name}'."
            )

            module_name = self.DEFAULT_STAGE_MODULES.get(stage)
            if module_name is None:
                raise ValueError(f"Unknown pipeline stage: '{stage}'.")

            plugin = self.registry.get(module_name, action_name)
            result = self._invoke(plugin, args, kwargs)

            # Store the stage result in the collector so later stages can use it.
            self.collector.set(stage, result)
            self.results.append(result)

        self.logger.info("Evaluation pipeline completed.")
        return self.collector.as_dict()

    def _invoke(
        self,
        plugin: Any,
        args: List[Any],
        kwargs: Dict[str, Any],
    ) -> Any:
        """Invoke a registered plugin as a function or class instance.

        Positional ``args`` and keyword ``kwargs`` come from the step
        configuration. ``logger`` and ``collector`` are injected only when the
        plugin's signature accepts them.
        """
        if inspect.isclass(plugin):
            instance = plugin(
                config=kwargs,
                logger=self.logger,
                collector=self.collector,
            )
            run_method = getattr(instance, "run")
            sig = inspect.signature(run_method)
            bound_kwargs = self._filter_kwargs(sig, kwargs)
            return run_method(*args, **bound_kwargs)

        if inspect.isfunction(plugin) or callable(plugin):
            sig = inspect.signature(plugin)
            bound_kwargs = self._filter_kwargs(sig, kwargs)
            if "logger" in sig.parameters:
                bound_kwargs["logger"] = self.logger
            if "collector" in sig.parameters:
                bound_kwargs["collector"] = self.collector
            return plugin(*args, **bound_kwargs)

        raise TypeError(f"Unsupported plugin type: {type(plugin)}")

    def _filter_kwargs(
        self,
        signature: inspect.Signature,
        kwargs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Return only the kwargs accepted by the given signature.

        If the signature contains ``**kwargs``, all keyword arguments are kept.
        """
        has_var_kwargs = any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in signature.parameters.values()
        )
        if has_var_kwargs:
            return dict(kwargs)
        return {k: v for k, v in kwargs.items() if k in signature.parameters}
