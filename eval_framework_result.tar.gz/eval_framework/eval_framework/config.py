"""Configuration loading and validation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List


class Config:
    """Wrapper around the evaluation configuration file.

    Supports both JSON and YAML configuration files. The expected schema is:

    .. code-block:: yaml

        log_level: str
        pipelines:
          - load_dataset:
              action: my_dataset_loader
              args: [dataset_path]
              kwargs:
                split: train
          - preprocess:
              action: my_preprocessor
              kwargs: {key: value}
          - load_model:
              action: my_model_loader
              args: [model_path]
          - inference:
              action: my_inference
          - collect:
              action: my_collector
          - process_result:
              action: my_processor
          - measurement:
              action: my_measurer

    Each pipeline step must specify an ``action``. Positional arguments for the
    action are provided via ``args`` (a list), and keyword arguments via
    ``kwargs`` (a dict). Any additional keys in the step dict are also treated
    as keyword arguments for backward compatibility.
    """

    REQUIRED_KEYS = {"pipelines"}

    def __init__(self, path: str) -> None:
        self.path = Path(path)
        self._raw: Dict[str, Any] = self._load()
        self._validate()

    def _load(self) -> Dict[str, Any]:
        if not self.path.exists():
            raise FileNotFoundError(f"Config file not found: {self.path}")
        text = self.path.read_text(encoding="utf-8")
        suffix = self.path.suffix.lower()
        if suffix in {".json"}:
            return json.loads(text)
        if suffix in {".yaml", ".yml"}:
            try:
                import yaml
            except ImportError as exc:
                raise ImportError(
                    "PyYAML is required to load YAML config files."
                ) from exc
            return yaml.safe_load(text)
        raise ValueError(
            f"Unsupported config format: {self.path.suffix}. Use .json, .yaml, or .yml."
        )

    def _validate(self) -> None:
        missing = self.REQUIRED_KEYS - set(self._raw.keys())
        if missing:
            raise ValueError(f"Missing required config keys: {sorted(missing)}")
        if not isinstance(self._raw["pipelines"], list):
            raise ValueError("'pipelines' must be a list of action dictionaries.")

    @property
    def model(self) -> Any:
        return self._raw.get("model")

    @property
    def dataset(self) -> Any:
        return self._raw.get("dataset")

    @property
    def dataset_proc(self) -> str:
        return self._raw.get("dataset_proc", "default")

    @property
    def log_level(self) -> str:
        return self._raw.get("log_level", "INFO")

    @property
    def pipelines(self) -> List[Dict[str, Any]]:
        return self._raw["pipelines"]

    def pipeline_steps(self) -> List[Dict[str, Any]]:
        """Normalize pipeline steps into structured dicts.

        Each returned dict contains:
            - stage: pipeline stage name
            - action: registered action name
            - args: list of positional arguments
            - kwargs: dict of keyword arguments
        """
        steps: List[Dict[str, Any]] = []
        for item in self._raw["pipelines"]:
            if not isinstance(item, dict):
                raise ValueError(f"Invalid pipeline item: {item}")
            for stage, action_cfg in item.items():
                if isinstance(action_cfg, str):
                    steps.append(
                        {"stage": stage, "action": action_cfg, "args": [], "kwargs": {}}
                    )
                elif isinstance(action_cfg, dict):
                    action_name = action_cfg.get("action")
                    if action_name is None:
                        raise ValueError(
                            f"Pipeline stage '{stage}' is missing 'action' key."
                        )
                    args = action_cfg.get("args", [])
                    if not isinstance(args, list):
                        raise ValueError(
                            f"'args' for stage '{stage}' must be a list."
                        )
                    kwargs = dict(action_cfg.get("kwargs", {}))
                    # Any extra keys are also treated as keyword arguments.
                    for key, value in action_cfg.items():
                        if key not in {"action", "args", "kwargs"}:
                            kwargs[key] = value
                    steps.append(
                        {
                            "stage": stage,
                            "action": action_name,
                            "args": args,
                            "kwargs": kwargs,
                        }
                    )
                else:
                    raise ValueError(
                        f"Invalid action config for stage '{stage}': {action_cfg}"
                    )
        return steps

    def get(self, key: str, default: Any = None) -> Any:
        """Access arbitrary config values."""
        return self._raw.get(key, default)
