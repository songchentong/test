"""Collector for intermediate and final evaluation data."""

from __future__ import annotations

from typing import Any, Dict, List, Optional


class Collector:
    """Collects data produced during evaluation.

    The collector is shared across pipeline stages. Any stage can store data
    under a key, and subsequent stages can read or append to it. This is
    useful for recording per-sample predictions, raw model outputs, timing,
    and any other information required for final measurement.
    """

    def __init__(self) -> None:
        self._data: Dict[str, Any] = {}

    def set(self, key: str, value: Any) -> None:
        """Store ``value`` under ``key``."""
        self._data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve a value by key."""
        return self._data.get(key, default)

    def append(self, key: str, value: Any) -> None:
        """Append ``value`` to the list stored under ``key``.

        If no list exists, a new list is created.
        """
        if key not in self._data:
            self._data[key] = []
        if not isinstance(self._data[key], list):
            raise TypeError(f"Cannot append to non-list value at key '{key}'.")
        self._data[key].append(value)

    def extend(self, key: str, values: List[Any]) -> None:
        """Extend the list stored under ``key`` with ``values``."""
        if key not in self._data:
            self._data[key] = []
        if not isinstance(self._data[key], list):
            raise TypeError(f"Cannot extend non-list value at key '{key}'.")
        self._data[key].extend(values)

    def has(self, key: str) -> bool:
        """Return True if ``key`` exists."""
        return key in self._data

    def keys(self) -> List[str]:
        """Return all stored keys."""
        return list(self._data.keys())

    def clear(self) -> None:
        """Remove all collected data."""
        self._data.clear()

    def as_dict(self) -> Dict[str, Any]:
        """Return a shallow copy of all collected data."""
        return self._data.copy()
